# VELORA — ASSETS-README

Всего PNG: **103**. Файлы увеличены в 2× относительно исходного изображения. Папки соответствуют разделам исходного макета.

Русский текст на баннерах, карточках и плашках — часть исходного арта.

| Путь | Назначение | Размер, px | Прозрачный фон |
|---|---|---|---|
| `assets/backgrounds/main/background-1.png` | Вертикальный фон (раздел «Фоны») | 170x470 | нет |
| `assets/backgrounds/main/background-2.png` | Вертикальный фон (раздел «Фоны») | 170x470 | нет |
| `assets/backgrounds/main/background-3.png` | Вертикальный фон (раздел «Фоны») | 172x470 | нет |
| `assets/backgrounds/main/background-4.png` | Вертикальный фон (раздел «Фоны») | 170x470 | нет |
| `assets/backgrounds/main/background-5.png` | Вертикальный фон (раздел «Фоны») | 170x470 | нет |
| `assets/backgrounds/main/background-6.png` | Вертикальный фон (раздел «Фоны») | 104x470 | нет |
| `assets/banners/events/crystal-festival-banner.png` | Баннер события | 532x168 | нет |
| `assets/banners/events/global-battle-banner.png` | Баннер события | 532x196 | нет |
| `assets/banners/main/main-banner.png` | Главный баннер | 926x582 | нет |
| `assets/banners/promotions/season-pass-banner.png` | Промо-баннер (Season Pass) | 532x170 | нет |
| `assets/banners/season/season-crystal-awakening-banner.png` | Баннер сезона/события (раздел «Сезон и события») | 502x206 | нет |
| `assets/banners/season/shadow-of-past-banner.png` | Баннер сезона/события (раздел «Сезон и события») | 502x180 | нет |
| `assets/banners/season/summer-festival-banner.png` | Баннер сезона/события (раздел «Сезон и события») | 502x200 | нет |
| `assets/banners/worlds/world-1-banner.png` | Изображение игрового мира (раздел «Игровые миры») | 310x226 | нет |
| `assets/banners/worlds/world-2-banner.png` | Изображение игрового мира (раздел «Игровые миры») | 292x226 | нет |
| `assets/banners/worlds/world-3-banner.png` | Изображение игрового мира (раздел «Игровые миры») | 310x224 | нет |
| `assets/banners/worlds/world-4-banner.png` | Изображение игрового мира (раздел «Игровые миры») | 292x224 | нет |
| `assets/cards/characters/card-common.png` | Карточка редкости: обычная/редкая/эпическая/легендарная | 126x186 | нет |
| `assets/cards/characters/card-epic.png` | Карточка редкости: обычная/редкая/эпическая/легендарная | 128x186 | нет |
| `assets/cards/characters/card-legendary.png` | Карточка редкости: обычная/редкая/эпическая/легендарная | 130x186 | нет |
| `assets/cards/characters/card-rare.png` | Карточка редкости: обычная/редкая/эпическая/легендарная | 126x186 | нет |
| `assets/cards/items/card-chest.png` | Карточка предмета (раздел «Карточки и предметы») | 126x186 | нет |
| `assets/cards/items/card-coin.png` | Карточка предмета (раздел «Карточки и предметы») | 128x186 | нет |
| `assets/cards/items/card-potion.png` | Карточка предмета (раздел «Карточки и предметы») | 130x186 | нет |
| `assets/cards/items/card-resource.png` | Карточка предмета (раздел «Карточки и предметы») | 126x186 | нет |
| `assets/characters/lumi/lumi-emotion-angry.png` | Персонаж Луми и его эмоции (раздел «Луми») | 101x129 | да |
| `assets/characters/lumi/lumi-emotion-bye.png` | Персонаж Луми и его эмоции (раздел «Луми») | 101x125 | да |
| `assets/characters/lumi/lumi-emotion-cool.png` | Персонаж Луми и его эмоции (раздел «Луми») | 98x134 | да |
| `assets/characters/lumi/lumi-emotion-hello.png` | Персонаж Луми и его эмоции (раздел «Луми») | 102x125 | да |
| `assets/characters/lumi/lumi-emotion-joy.png` | Персонаж Луми и его эмоции (раздел «Луми») | 101x132 | да |
| `assets/characters/lumi/lumi-emotion-laugh.png` | Персонаж Луми и его эмоции (раздел «Луми») | 100x129 | да |
| `assets/characters/lumi/lumi-emotion-love.png` | Персонаж Луми и его эмоции (раздел «Луми») | 102x129 | да |
| `assets/characters/lumi/lumi-emotion-party.png` | Персонаж Луми и его эмоции (раздел «Луми») | 102x125 | да |
| `assets/characters/lumi/lumi-emotion-scared.png` | Персонаж Луми и его эмоции (раздел «Луми») | 103x127 | да |
| `assets/characters/lumi/lumi-emotion-sleepy.png` | Персонаж Луми и его эмоции (раздел «Луми») | 97x126 | да |
| `assets/characters/lumi/lumi-emotion-surprise.png` | Персонаж Луми и его эмоции (раздел «Луми») | 102x125 | да |
| `assets/characters/lumi/lumi-emotion-thinking.png` | Персонаж Луми и его эмоции (раздел «Луми») | 95x125 | да |
| `assets/characters/lumi/lumi-main.png` | Персонаж Луми и его эмоции (раздел «Луми») | 302x570 | нет |
| `assets/decorations/decorative-bar.png` | Декоративная рамка | 270x70 | да |
| `assets/frames/cards/item-frame-icon.png` | Рамка предмета | 114x121 | да |
| `assets/frames/profiles/profile-frame-1.png` | Рамки профиля 1–4 и титульные плашки (раздел «Рамки, значки, титулы») | 146x165 | да |
| `assets/frames/profiles/profile-frame-2.png` | Рамки профиля 1–4 и титульные плашки (раздел «Рамки, значки, титулы») | 143x164 | да |
| `assets/frames/profiles/profile-frame-3.png` | Рамки профиля 1–4 и титульные плашки (раздел «Рамки, значки, титулы») | 139x162 | да |
| `assets/frames/profiles/profile-frame-4.png` | Рамки профиля 1–4 и титульные плашки (раздел «Рамки, значки, титулы») | 151x166 | да |
| `assets/frames/profiles/profile-title-1.png` | Рамки профиля 1–4 и титульные плашки (раздел «Рамки, значки, титулы») | 132x69 | да |
| `assets/frames/profiles/profile-title-2.png` | Рамки профиля 1–4 и титульные плашки (раздел «Рамки, значки, титулы») | 120x69 | да |
| `assets/frames/profiles/profile-title-3.png` | Рамки профиля 1–4 и титульные плашки (раздел «Рамки, значки, титулы») | 124x73 | да |
| `assets/frames/profiles/profile-title-4.png` | Рамки профиля 1–4 и титульные плашки (раздел «Рамки, значки, титулы») | 130x69 | да |
| `assets/games/game-arcade-card.png` | Карточка игрового режима (раздел «Игровые режимы») | 198x286 | нет |
| `assets/games/game-battle-card.png` | Карточка игрового режима (раздел «Игровые режимы») | 186x286 | нет |
| `assets/games/game-memory-card.png` | Карточка игрового режима (раздел «Игровые режимы») | 198x286 | нет |
| `assets/games/game-puzzle-card.png` | Карточка игрового режима (раздел «Игровые режимы») | 198x286 | нет |
| `assets/games/game-quests-card.png` | Карточка игрового режима (раздел «Игровые режимы») | 198x286 | нет |
| `assets/games/game-racing-card.png` | Карточка игрового режима (раздел «Игровые режимы») | 198x286 | нет |
| `assets/games/game-run-card.png` | Карточка игрового режима (раздел «Игровые режимы») | 198x286 | нет |
| `assets/games/game-survival-card.png` | Карточка игрового режима (раздел «Игровые режимы») | 186x286 | нет |
| `assets/games/game-tournaments-card.png` | Карточка игрового режима (раздел «Игровые режимы») | 188x286 | нет |
| `assets/games/game-words-card.png` | Карточка игрового режима (раздел «Игровые режимы») | 188x286 | нет |
| `assets/icons/achievements/achievement-badge-1.png` | Значок достижения (раздел «Рамки, значки, титулы») | 125x139 | да |
| `assets/icons/achievements/achievement-badge-2.png` | Значок достижения (раздел «Рамки, значки, титулы») | 126x140 | да |
| `assets/icons/achievements/achievement-badge-3.png` | Значок достижения (раздел «Рамки, значки, титулы») | 124x139 | да |
| `assets/icons/achievements/achievement-badge-4.png` | Значок достижения (раздел «Рамки, значки, титулы») | 120x138 | да |
| `assets/icons/currency/coin-icon.png` | Иконка валюты | 102x125 | да |
| `assets/icons/currency/crystal-icon.png` | Иконка валюты | 112x128 | да |
| `assets/icons/currency/energy-icon.png` | Иконка валюты | 110x128 | да |
| `assets/icons/currency/season-currency-icon.png` | Иконка валюты | 97x130 | да |
| `assets/icons/currency/xp-icon.png` | Иконка валюты | 102x124 | да |
| `assets/icons/interface/active-pill-blue.png` | Элемент интерфейса (раздел «Интерфейс и элементы») | 96x42 | да |
| `assets/icons/interface/active-pill-green.png` | Элемент интерфейса (раздел «Интерфейс и элементы») | 107x42 | да |
| `assets/icons/interface/level-bar.png` | Элемент интерфейса (раздел «Интерфейс и элементы») | 320x36 | да |
| `assets/icons/interface/new-badge.png` | Элемент интерфейса (раздел «Интерфейс и элементы») | 96x71 | да |
| `assets/icons/interface/notification-bell.png` | Элемент интерфейса (раздел «Интерфейс и элементы») | 92x78 | да |
| `assets/icons/interface/progress-bar.png` | Элемент интерфейса (раздел «Интерфейс и элементы») | 334x36 | да |
| `assets/icons/interface/status-diamond-icon.png` | Элемент интерфейса (раздел «Интерфейс и элементы») | 74x72 | да |
| `assets/icons/interface/status-eye-icon.png` | Элемент интерфейса (раздел «Интерфейс и элементы») | 86x60 | да |
| `assets/icons/interface/toggle-switch.png` | Элемент интерфейса (раздел «Интерфейс и элементы») | 94x52 | да |
| `assets/icons/items/background-item-icon.png` | Иконка предмета | 94x116 | нет |
| `assets/icons/items/chest-icon.png` | Иконка предмета | 128x132 | да |
| `assets/icons/items/crown-icon.png` | Иконка предмета | 113x106 | да |
| `assets/icons/items/key-icon.png` | Иконка предмета | 105x129 | да |
| `assets/icons/items/pet-icon.png` | Иконка предмета | 117x123 | да |
| `assets/icons/items/potion-icon.png` | Иконка предмета | 105x132 | да |
| `assets/icons/items/scroll-icon.png` | Иконка предмета | 109x131 | да |
| `assets/icons/items/wings-icon.png` | Иконка предмета | 128x132 | да |
| `assets/icons/navigation/home-button.png` | Навигация | 116x80 | да |
| `assets/icons/navigation/tabs-bar.png` | Навигация | 261x66 | да |
| `assets/icons/resources/crystal-set-icon.png` | Иконка ресурса | 115x132 | да |
| `assets/misc/blue-flower-icon.png` | Дополнительные элементы / стикеры | 79x79 | да |
| `assets/misc/blue-gem-icon.png` | Дополнительные элементы / стикеры | 79x83 | да |
| `assets/misc/butterfly-icon.png` | Дополнительные элементы / стикеры | 93x112 | да |
| `assets/misc/crystal-blue-icon.png` | Дополнительные элементы / стикеры | 95x112 | да |
| `assets/misc/crystal-purple-icon.png` | Дополнительные элементы / стикеры | 110x112 | да |
| `assets/misc/gg-sticker-blue.png` | Дополнительные элементы / стикеры | 85x66 | да |
| `assets/misc/go-sticker.png` | Дополнительные элементы / стикеры | 91x77 | да |
| `assets/misc/heart-icon.png` | Дополнительные элементы / стикеры | 72x67 | да |
| `assets/misc/lumi-sticker-1.png` | Дополнительные элементы / стикеры | 102x106 | да |
| `assets/misc/lumi-sticker-2.png` | Дополнительные элементы / стикеры | 100x92 | да |
| `assets/misc/lumi-sticker-3.png` | Дополнительные элементы / стикеры | 101x105 | да |
| `assets/misc/lumi-sticker-4.png` | Дополнительные элементы / стикеры | 88x106 | да |
| `assets/misc/lumi-sticker-5.png` | Дополнительные элементы / стикеры | 108x97 | да |
| `assets/misc/star-emblem-icon.png` | Дополнительные элементы / стикеры | 110x112 | да |
| `assets/misc/star-icon.png` | Дополнительные элементы / стикеры | 81x82 | да |
| `assets/misc/wow-sticker.png` | Дополнительные элементы / стикеры | 91x68 | да |

## Загрузка в GitHub
1. Распакуйте VELORA_ASSETS.zip — получится папка `assets/`.
2. Скопируйте `assets/` в корень репозитория.
3. `git add assets && git commit -m "Add game assets" && git push`
   Или на github.com: Add file → Upload files → перетащите папку `assets` → Commit changes.